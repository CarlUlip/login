<?php
defined('PREVENT_DIRECT_ACCESS') or exit('No direct script access allowed');

class User extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->call->model('user_model');
        $this->call->library('email');
    }

    public function register()
    {
        if ($this->form_validation->submitted()) {
            $cjru_username = $this->io->post('cjru_username');
            $cjru_gmail = $this->io->post('cjru_gmail');
            $cjru_password = $this->io->post('cjru_password');

            if ($this->user_model->register($cjru_username, $cjru_gmail, $cjru_password)) {
                $this->cjru_gmail->from('carljancellulip.com', 'Admin');
                $this->cjru_gmail->to($cjru_gmail);
                $this->cjru_gmail->subject('Welcome to the System');
                $this->cjru_gmail->message('Thank you for registering, ' . $cjru_username . '!');

                if ($this->cjru_gmail->send()) {
                    $_SESSION['registration_success'] = 'Registration successful! You can now log in.';
                } else {
                    $_SESSION['registration_error'] = 'Registration successful, but email sending failed.';
                }

                header('Location: ' . site_url('user/login'));
                exit;
            } else {
                $_SESSION['registration_error'] = 'Registration failed. Please try again.';
                header('Location: ' . site_url('user/register'));
                exit;
            }
        }

        $this->call->view('user/register');
    }


    public function login()
    {
        if ($this->form_validation->submitted()) {
            $cjru_gmail = $this->io->post('cjru_gmail');
            $cjru_password = $this->io->post('cjru_password');

            // Check login
            if ($cjru_user = $this->user_model->login($cjru_gmail, $cjru_password)) {
                $_SESSION['cjru_user'] = $cjru_user;
                header('Location: ' . site_url('student/display'));
                exit;
            } else {
                echo 'Invalid login credentials.';
            }
        }
        $this->call->view('user/login');
    }
    public function logout()
    {
        session_destroy();
        header('Location: ' . site_url('user/login'));
        exit;
    }
}
?>