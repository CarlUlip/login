<?php
defined('PREVENT_DIRECT_ACCESS') or exit('No direct script access allowed');

class Student_model extends Model
{
    public function read()
    {
        return $this->db->table('cjru_users')->get_all();
    }

    public function get_paginated($limit, $offset)
    {
        return $this->db->table('cjru_users')->limit($limit, $offset)->get_all();
    }

    public function get_total_count()
    {
        $results = $this->db->table('cjru_users')->get_all(); // Fetch all records
        return count($results); // Count the records
    }

    public function create($cjru_lastname, $cjru_firstname, $cjru_address, $cjru_email, $cjru_gender)
    {
        $data = array(
            'cjru_lastname' => $cjru_lastname,
            'cjru_firstname' => $cjru_firstname,
            'cjru_address' => $cjru_address,
            'cjru_email' => $cjru_email,
            'cjru_gender' => $cjru_gender
        );
        return $this->db->table('cjru_users')->insert($data);
    }

    public function get_one($id)
    {
        return $this->db->table('cjru_users')->where('id', $id)->get();
    }

    public function update($id, $cjru_lastname, $cjru_firstname, $cjru_address, $cjru_email, $cjru_gender)
    {
        $data = array(
            'cjru_lastname' => $cjru_lastname,
            'cjru_firstname' => $cjru_firstname,
            'cjru_address' => $cjru_address,
            'cjru_email' => $cjru_email,
            'cjru_gender' => $cjru_gender
        );
        return $this->db->table('cjru_users')->where('id', $id)->update($data);
    }

    public function delete($id)
    {
        return $this->db->table('cjru_users')->where('id', $id)->delete();
    }


    public function search_students($query)
    {
        $this->db->table('cjru_users');
        $this->db->like('id', $query);
        $this->db->or_like('cjru_lastname', $query);
        return $this->db->get_all();
    }
}
?>