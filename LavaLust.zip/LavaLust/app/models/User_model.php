<?php
defined('PREVENT_DIRECT_ACCESS') or exit('No direct script access allowed');

class User_model extends Model
{
    public function register($cjru_username, $cjru_gmail, $cjru_password)
    {
        $data = array(
            'cjru_username' => $cjru_username,
            'cjru_gmail' => $cjru_gmail,
            'cjru_password' => password_hash($cjru_password, PASSWORD_BCRYPT),
        );
        return $this->db->table('cjru_user')->insert($data);
    }

    public function login($cjru_gmail, $cjru_password)
    {
        $cjru_user = $this->db->table('cjru_user')->where('cjru_gmail', $cjru_gmail)->get();
        if ($cjru_user && password_verify($cjru_password, $cjru_user['cjru_password'])) {
            return $cjru_user;
        }
        return false;
    }
}
?>