<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #deedde;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            /* Add margin to the top */
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="email"] {
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }

        button {
            padding: 10px 15px;
            margin: 5px 0;
            border: none;
            border-radius: 4px;
            color: #fff;
            background-color: #007bff;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        a {
            text-decoration: none;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
        }

        .back-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px 15px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Update Student Info</h1>

        <form action="<?= site_url('student/update/' . segment(3)); ?>" method="POST">
            <label for="cjru_lastname">Last Name:</label>
            <input type="text" id="cjru_lastname" name="cjru_lastname" required
                value="<?= $ulip_student['cjru_lastname']; ?>">

            <label for="cjru_firstname">First Name:</label>
            <input type="text" id="cjru_firstname" name="cjru_firstname" required
                value="<?= $ulip_student['cjru_firstname']; ?>">

            <label for="cjru_address">Address:</label>
            <input type="text" id="cjru_address" name="cjru_address" required
                value="<?= $ulip_student['cjru_address']; ?>">

            <label for="cjru_email">Email:</label>
            <input type="email" id="cjru_email" name="cjru_email" required value="<?= $ulip_student['cjru_email']; ?>">

            <label for="cjru_gender">Gender:</label>
            <input type="text" id="cjru_gender" name="cjru_gender" required
                value="<?= $ulip_student['cjru_gender']; ?>">

            <div class="button-container">
                <button type="submit">Update</button>
                <a href="<?= site_url('student/display'); ?>"><button type="button" class="back-btn">Back</button></a>
            </div>
        </form>
    </div>

</body>

</html>