<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #deedde;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Login</h2>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="post" action="<?= site_url('user/login'); ?>">
            <div class="mb-3">
                <label for="cjru_gmail" class="form-label">Email</label>
                <input type="email" class="form-control" id="cjru_gmail" name="cjru_gmail" required>
            </div>
            <div class="mb-3">
                <label for="cjru_password" class="form-label">Password</label>
                <input type="password" class="form-control" id="cjru_password" name="cjru_password" required>
            </div>

            <div class="button-container">
                <button type="submit" class="btn btn-primary">Login</button>
            </div>
        </form>

        <div class="mt-3 text-center">
            <p>Don't have an account? <a href="<?= site_url('user/register'); ?>">Register Here</a></p>
        </div>
    </div>
</body>

</html>